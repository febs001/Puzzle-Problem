/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domains.arithmetic;
import java.util.stream.Stream;
import framework.problem.State;

/**
 *
 * Angelica Fleury Lab 1PM Wednesday
 */
public class ArithmeticState implements State {
    
    public ArithmeticState(int contents)
    {
        this.contents = contents;
    }
    
    @Override
    public boolean equals(Object other){
        ArithmeticState otherArithmetic = (ArithmeticState) other;
        return this.contents.equals(otherArithmetic.contents);
        
    }
    
    @Override
    public String toString()
    {
        String trueString = "The value is: ";
        String castString = Integer.toString(contents);
        trueString = trueString + castString;
        return trueString;
    }
    
    public int getContents()
    {
        return contents;
    }
    
    private final Integer contents;

    private static final String NEW_LINE = "\n";
            
    
}
