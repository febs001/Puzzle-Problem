package domains.farmer;

import framework.graph.Graph;
import framework.graph.Vertex;

/**
 * A graph for the FWGC problem.
 * @author Your name and section here
 */
public class FarmerGraph extends Graph {
    
    public FarmerGraph() {
        /* you must provide */
         wwww= new Vertex(new FarmerState("West", "West", "West", "West")); //create the vertices for the graph representation  
         ewew= new Vertex(new FarmerState("East", "West", "East", "West"));
         wwew= new Vertex(new FarmerState("West", "West", "East", "West"));
         eeew= new Vertex(new FarmerState("East", "East", "East", "West"));
         weww= new Vertex(new FarmerState("West", "East", "West", "West"));
         weww= new Vertex(new FarmerState("West", "East", "West", "West"));
         ewee= new Vertex(new FarmerState("East", "West", "East", "East"));
         wwwe= new Vertex(new FarmerState("West", "West", "West", "East"));
         eewe= new Vertex(new FarmerState("East", "East", "West", "East"));
         wewe= new Vertex(new FarmerState("West", "East", "West", "East"));
         eeee= new Vertex(new FarmerState("East", "East", "East", "East"));
         
         //graph = new Graph();
         this.addEdge(wwww,ewew); //create edges for the graph representation, make sure to look at ALL POSSIBLE EDGES 
         this.addEdge(ewew, wwww);
         this.addEdge(ewew,wwew);
         this.addEdge(wwew,ewew);
         this.addEdge(wwew,eeew);
         this.addEdge(eeew,wwew);
         this.addEdge(eeew,weww);
         this.addEdge(weww,eeew);
         this.addEdge(weww,eewe);
         this.addEdge(eewe,weww);
         this.addEdge(eewe,wwwe);
         this.addEdge(wwwe,eewe);
         this.addEdge(wwwe,ewee);
         this.addEdge(ewee,wwwe);
         this.addEdge(ewee,wwew);
         this.addEdge(wwew, ewee);
         this.addEdge(eewe,wewe);
         this.addEdge(wewe,eewe);
         this.addEdge(wewe,eeee);
         this.addEdge(eeee,wewe);
         
         
    }
     
    public Vertex getStart() {
        /* you must provide */
        return wwww;
        
    }
    
    public Vertex getEnd() {
        /* you must provide */
        return eeee;
    }
    
    /* private fields and methods follow */
    private Vertex wwww;
    private Vertex ewew;
    private Vertex wwew;
    private Vertex eeew;
    private Vertex weww;
    private Vertex ewee;
    private Vertex wwwe;
    private Vertex eewe;
    private Vertex wewe;
    private Vertex eeee;
    //private Graph graph;
}