/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domains.farmer;
import framework.problem.Mover;
import framework.problem.State;

/**
 *
 * @author febs
 */
public class FarmerMover extends Mover {
    public static final String GOESALONE = "Farmer goes alone" ;
    public static final String TAKESGOAT = "Farmer takes goat";
    public static final String TAKESCABBAGE = "Farmer takes cabbage";
    public static final String TAKESWOLF = "Farmer takes wolf";
    
    public FarmerMover()
    {
        super.addMove(GOESALONE, s -> goesAlone((FarmerState)s));
        super.addMove(TAKESWOLF, s -> takesWolf((FarmerState)s));
        super.addMove(TAKESGOAT, s -> takesGoat((FarmerState)s));
        super.addMove(TAKESCABBAGE, s -> takesCabbage((FarmerState)s));
 
    }
    
    private State goesAlone(FarmerState s)
    {
        if(s.getWolf().equals(s.getGoat()))
        {
            return null;
        }
        else if(s.getGoat().equals(s.getCabbage()))
        {
            return null;
        }
        if(s.getFarmer().equals("West"))
        {
            return new FarmerState("East",s.getWolf(),s.getGoat(),s.getCabbage());
        }
        else
        {
            return new FarmerState("West", s.getWolf(), s.getGoat(),s.getCabbage());
        }
        //check if possible -> s.getWolf.equals(s.getGoat); -> return null
        //return null if goat is same side as cabbage 
        
    }
    private State takesGoat(FarmerState s)
    {
        if(!s.getGoat().equals(s.getFarmer()))
        {
            return null;
        }
        if(s.getFarmer().equals("West"))
        {
            return new FarmerState("East", s.getWolf(),"East",s.getCabbage());
        }
        else
        {
            return new FarmerState("West", s.getWolf(), "West",s.getCabbage());
        }
        
    }
    private State takesCabbage(FarmerState s)
    {
       if(s.getWolf().equals(s.getGoat()))
       {
           return null;
       }
       else if(!s.getFarmer().equals(s.getCabbage()))
       {
           return null;
       }
       if(s.getFarmer().equals("West"))
        {
            return new FarmerState("East", s.getWolf(),s.getGoat(),"East");
        }
        else
        {
            return new FarmerState("West", s.getWolf(),s.getGoat(),"West");
        }
       
    }
    private State takesWolf(FarmerState s)
    {
        if(s.getCabbage().equals(s.getGoat()))
        {
            return null;
        }
        else if(!s.getWolf().equals(s.getFarmer()))
        {
          return null;
        }
        if(s.getFarmer().equals("West"))
        {
            return new FarmerState("East", "East",s.getGoat(),s.getCabbage());
        }
        else
        {
            return new FarmerState("West", "West",s.getGoat(),s.getCabbage());
        }
        
    }
 
}
