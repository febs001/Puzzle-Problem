/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domains.farmer;
import framework.problem.State;
import java.util.Objects;

/**
 *
 * @author febs
 */
public class FarmerState implements State {
    
    public FarmerState(String f, String w, String g, String c) //constructor for farmer, wold, cabbage, goat 
    {
        this.f = f;
        this.w = w;
        this.c = c;
        this.g = g;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 53 * hash + Objects.hashCode(this.f);
        hash = 53 * hash + Objects.hashCode(this.w);
        hash = 53 * hash + Objects.hashCode(this.c);
        hash = 53 * hash + Objects.hashCode(this.g);
        return hash;
    }
   
    
    @Override 
    public boolean equals(Object other)
    {
        if(other == null)
        {
            return false;
        }
        FarmerState otherFarmer = (FarmerState) other;
        
        return this.f.equals(otherFarmer.f) && 
        this.w.equals(otherFarmer.w) && 
        this.g.equals(otherFarmer.g) &&
        this.c.equals(otherFarmer.c);
            
    }
    
    @Override
    public String toString()
    {
        StringBuilder b = new StringBuilder();
        b.append("   |  |   \n");
        if(f == "West")
        {
            b.append(" F |  |   \n");
        }
        else if(f == "East")
        {
            b.append("   |  | F \n");
        }
        if(w == "West")
        {
          b.append(" W |  |   \n");
        }
        else if(w == "East")
        {
            b.append("   |  | W \n");
        }
        if(g == "West")
        {
          b.append(" G |  |   \n");
        }
        else if(g == "East")
        {
            b.append("   |  | G \n");
        }
        if(c == "West")
        {
          b.append(" C |  |   \n");
        }
        else if(c == "East")
        {
            b.append("   |  | C \n");
        }
        b.append("   |  |   ");
         
        return b.toString();
    }
    
    public String getFarmer()
    {
        return f;
    }
    public String getWolf()
    {
        return w;
    }
    public String getCabbage()
    {
        return c;
    }
    public String getGoat()
    {
        return g;
    }
    
    
    private final String f;
    private final String w;
    private final String c;
    private final String g;
}
