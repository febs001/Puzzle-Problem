/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package domains.puzzle;
import domains.puzzle.PuzzleState.Location;
import framework.problem.Mover;
import framework.problem.State;



/**
 *
 * @author febs
 */
public class PuzzleMover extends Mover{
    
    public static final String SLIDE1 = "Slide tile 1";
    public static final String SLIDE2 = "Slide tile 2";
    public static final String SLIDE3 = "Slide tile 3";
    public static final String SLIDE4 = "Slide tile 4";
    public static final String SLIDE5 = "Slide tile 5";
    public static final String SLIDE6 = "Slide tile 6";
    public static final String SLIDE7 = "Slide tile 7";
    public static final String SLIDE8 = "Slide tile 8";
    
    public PuzzleMover()
    {
        super.addMove(SLIDE1, s -> trySlide1((PuzzleState)s));
        super.addMove(SLIDE2, s -> trySlide2((PuzzleState)s));
        super.addMove(SLIDE3, s -> trySlide3((PuzzleState)s));
        super.addMove(SLIDE4, s -> trySlide4((PuzzleState)s));
        super.addMove(SLIDE5, s -> trySlide5((PuzzleState)s));
        super.addMove(SLIDE6, s -> trySlide6((PuzzleState)s));
        super.addMove(SLIDE7, s -> trySlide7((PuzzleState)s));
        super.addMove(SLIDE8, s -> trySlide8((PuzzleState)s));
    }
    
    private State trySlide1(PuzzleState s)
    {
        return trySlideHelper(s,1);
    }
    private State trySlide2(PuzzleState s)
    {
        return trySlideHelper(s,2);
    }
    private State trySlide3(PuzzleState s)
    {
        return trySlideHelper(s,3);
    }
    private State trySlide4(PuzzleState s)
    {
        return trySlideHelper(s,4);
    }
    private State trySlide5(PuzzleState s)
    {
        return trySlideHelper(s,5);
    }
    private State trySlide6(PuzzleState s)
    {
        return trySlideHelper(s,6);
    }
    private State trySlide7(PuzzleState s)
    {
        return trySlideHelper(s,7);
    }
    private State trySlide8(PuzzleState s)
    {
        return trySlideHelper(s,8);
    }
    
    private State trySlideHelper(PuzzleState s,int newlocation)
    {
        //get two locations 
        Location location1 = s.getLocation(newlocation);
        Location location0 = s.getLocation(0); //empty slide 
        
        //check to see if two locations are adjacent 
        if(location1.getRow() == location0.getRow())
        {
            if(location1.getColumn()-location0.getColumn() ==1 || location1.getColumn()-location0.getColumn() == -1)
            {
                return new PuzzleState(s,location1,location0);
            }
        }
        else if(location1.getColumn() == location0.getColumn())
        {
            if(location1.getRow()-location0.getRow() == 1 || location1.getRow() - location0.getRow() == -1)
            {
                return new PuzzleState(s, location1, location0);
            }
        }  
            return null;
    }
    
    

}
