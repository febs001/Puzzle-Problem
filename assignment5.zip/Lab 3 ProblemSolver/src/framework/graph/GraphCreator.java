package framework.graph;
import java.util.HashMap;
import framework.problem.Problem;
import framework.problem.State;
import java.util.List;
import java.util.Stack;

/**
 * @author Your name here
 */
public class GraphCreator {

    public Graph createGraphFor(Problem problem) {
        graph = new Graph();
        stack = new Stack<>();
        start = new Vertex(problem.getInitialState());
        stack.push(start);
        moves = problem.getMover().getMoveNames();
        while(!stack.isEmpty())
        {
            u = stack.pop();
            
            for(String m : moves) //for each string inside moves
            {
                next = problem.getMover().doMove(m,(State)u.getData()); 
                if(next != null)
                {
                    v = new Vertex(next);
                    if(graph.getVertices().containsKey(v))
                    {
                       
                       v = graph.getVertices().get(v); 
                    }
                    else
                    {
                       stack.push(v);
                    }
                    graph.addEdge(u,v);
                
                }
            }
        }
      
        return graph;
    }
    
    private Graph graph = null;
    private Stack<Vertex> stack = null;
    private Vertex start, u, v;
    private List<String> moves;
    private State next ;
    
    
    

    
    
}