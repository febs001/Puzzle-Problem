package framework.ui;

import domains.arithmetic.ArithmeticProblem;
import domains.dummy.DummyProblem;
import domains.farmer.FarmerProblem;
import domains.puzzle.PuzzleProblem;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;

/**
 * This class presents problem solving domains in a tabbed pane.
 */
public class ProblemApplication extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        TabPane tabPane = new TabPane();
        
	/* Add tabs using the following */
        
        //create new tabs
	Tab tabFarmer = new Tab();
        Tab tabDummy = new Tab();
        Tab tabArithmetic = new Tab();
        Tab tabPuzzle = new Tab();
        
        
        tabFarmer.setText("The Farmer Problem");
        tabDummy.setText("The Dummy Problem");
        tabArithmetic.setText("The Arithmetic Problem");
        tabPuzzle.setText("The 8-Puzzle Problem");
        
        tabFarmer.setContent(new ProblemGUI(new FarmerProblem(),800,700));
        tabDummy.setContent(new ProblemGUI(new DummyProblem(),800,700));
        tabArithmetic.setContent(new ProblemGUI(new ArithmeticProblem(), 800, 700));
        tabPuzzle.setContent(new ProblemGUI(new PuzzleProblem(), 800, 700));
        
        tabPane.getTabs().addAll(tabFarmer, tabDummy, tabArithmetic, tabPuzzle);
        
        Scene scene = new Scene(tabPane);
        primaryStage.setTitle("Problem Solver");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}