/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package framework.ui;

import domains.puzzle.PuzzleProblem;
import framework.problem.Benchmark;
import framework.problem.Problem;
import framework.problem.State;
import framework.solution.AStarSolver;
import framework.solution.Solver;
import framework.solution.SolvingAssistant;
import framework.solution.StateSpaceSolver;
import javafx.scene.paint.Color;
import java.awt.Container;
import javafx.geometry.Insets;
import java.awt.Paint;
import java.util.ArrayList;
import javafx.beans.Observable;
import javafx.beans.binding.Bindings;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;


/**
 *
 * @author febs
 */
public class ProblemGUI extends VBox {
    
    public ProblemGUI(Problem problem, double width, double height) {
        
    bfs = new StateSpaceSolver(problem,true);
    dfs = new StateSpaceSolver(problem,false);
    astar = new AStarSolver(problem);
    
    //create welcome message and introduction
    introduction = new Label(problem.getIntroduction()); 
    welcomeMessage = new Label("Welcome to the" +problem.getName()+ "Problem");
    currentState = new Label(problem.getCurrentState().toString()); //set labeL
    currentStateLabel = new Label("Current State:");
    
    /*
    Show welcome message, introduction, current state 
    */
   welcomeMessage.setFont(new Font("Courier New", 20));
   introduction.setFont(new Font("Courier New ", 15));
   introduction.setTextAlignment(TextAlignment.JUSTIFY);
   introduction.setPadding(new Insets(10,10,10,10));   
   welcomeMessage.setTextAlignment(TextAlignment.CENTER);
   
   
   //current state
   currentStateLabel.setFont(new Font("Courier New", 20));
   currentStateLabel.setTextAlignment(TextAlignment.CENTER);
   currentState.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(5))));
   currentState.setPadding(new Insets(10, 10, 10, 10));
   currentState.setFont(new Font("Courier New", 30));
   currentState.setAlignment(Pos.CENTER);
   
   
   //moves
   sa = new SolvingAssistant (problem);
   moves = new Label("");
   moves.setPadding(new Insets(10, 10, 10, 10));
   moves.setFont(new Font("Courier New", 20));

   //buttons 
   VBox vbButton = new VBox(8);
   
      
   //goal state
   goalState = new Label(problem.getFinalState().toString());
   goalStateLabel = new Label("Goal State:");
   goalStateLabel.setFont(new Font("Courier New", 20));
   goalStateLabel.setTextAlignment(TextAlignment.CENTER); 
   goalState.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(5))));
   goalState.setPadding(new Insets(10, 10, 10, 10));
   goalState.setFont(new Font("Courier New", 30));
   goalState.setAlignment(Pos.CENTER);
   
   //congratulatory label 
   congratulations = new Label("");
   congratulations.setFont(new Font("Courier New", 20));
   congratulations.setTextAlignment(TextAlignment.CENTER);
   congratulations.setTextFill(Color.RED);
   
   //Create the buttons and actions
   illegalMove = new Label("");
   vbButton.getChildren().add(moves);  
   //for each string create button to add to list and add lamba to perform internal state change in problem and change gui to update state
   ArrayList <String> moveNames = (ArrayList <String>) problem.getMover().getMoveNames();
   resetButton = new Button ("reset");
   moves.setText("Moves (0) so far:");
   
   for(int i = 0; i<problem.getMover().getMoveNames().size(); i++)
   {
       Button button = new Button (problem.getMover().getMoveNames().get(i)); //get all move names 
       button.setAlignment(Pos.CENTER);
       button.setPrefSize(200,25);
       button.setOnAction(
       e -> {
           sa.tryMove(button.getText()); //get names of the button
           moves.setText("Moves (" + sa.getMoveCount() + ") so far:" );
           //moves.setFont(new Font("Courier New", 20));
           moves.setTextAlignment(TextAlignment.CENTER);
           if(!sa.isMoveLegal())
           {
               illegalMove.setText("Move is not legal");
               illegalMove.setAlignment(Pos.CENTER);
           }
           else
           {
               illegalMove.setText("");
               
           }
           //sa.isProblemSolved();
           currentState.setText(problem.getCurrentState().toString());
           
           if(sa.isProblemSolved())
           {
               congratulations.setText("You solved the problem. Congratulations!");
  
           }
           else
           {
               congratulations.setText("");
           }

          //vbButton.disableProperty().bind(Bindings.not(solveButton.disableProperty()));
       });
       vbButton.getChildren().add(button);
       
       
   }
   
   
   //Search-Type Box and Label 
   Label searchLabel = new Label("Search Type");
   ChoiceBox searchType = new ChoiceBox<>();
   searchType.getItems().addAll("Breadth-First Search",
           "Depth-First Search", "A* Search");
   searchType.setValue("Breadth-First Search");
   solver = bfs;
   searchType.valueProperty().addListener((Observable o) -> {
       if(searchType.getValue().toString().equals("Breadth-First Search"))
       {
           solver = bfs;
           solver.getStatistics().setHeader("Breadth-First Search");
       }
       else if(searchType.getValue().toString().equals("Depth-First Search"))
       {
           
           solver = dfs;
           solver.getStatistics().setHeader("Depth-First Search");
       }
       else if(searchType.getValue().toString().equals("A* Search"))
       {
           
           solver = astar;
           solver.getStatistics().setHeader("A* Search");
       }
       else
       {
           return;
       }
  
   });
   Label benchmarkLabel = new Label("Benchmark");
   ChoiceBox benchmarkType = new ChoiceBox<>(FXCollections.observableArrayList(problem.getBenchmarks()));
   benchmarkType.valueProperty().addListener((Observable o) -> {
       
       Benchmark b = (Benchmark)benchmarkType.getValue();
       problem.setInitialState(b.getState());
       currentState.setText(problem.getInitialState().toString());
       sa.reset();//reset solver assistant
  
   });
   
   
   

   //Statistics Box and Label 
   Label statisticsLabel = new Label("Statistics");
   Label statisticsInfo = new Label("");
   statisticsInfo.setBorder(new Border(new BorderStroke(Color.BLACK, BorderStrokeStyle.SOLID, null, new BorderWidths(3))));
   statisticsInfo.setPrefSize(300,160);
   statisticsInfo.setFont(new Font("Courier New", 15));
   statisticsInfo.setAlignment(Pos.CENTER);
      //solve button actions
   //Solve Button Constructor 
   solveButton = new Button ("Solve");
   solveButton.setOnAction(e ->{
       solver.solve();
       statisticsInfo.setText(solver.getStatistics().toString());
       solveButton.disableProperty().set(true);
       vbButton.disableProperty().set(true);
       solver.getSolution().next();

   });
   resetButton.setOnAction(
   e ->{
       sa.reset();
       moves.setText("Moves (0) so far:");
       currentState.setText(problem.getInitialState().toString()); //v
       solveButton.setDisable(false);
       congratulations.setText("");
       counter = 0;
       statisticsInfo.setText("");
       vbButton.disableProperty().set(false);
   });
   //Next Button Constructor
   nextButton = new Button("Next");
   nextButton.disableProperty().bind(Bindings.not(solveButton.disableProperty()));
   nextButton.setOnAction((ActionEvent ev) -> {
       
       if(solver.getSolution().hasNext())
       {
          counter ++;
          currentState.setText(solver.getSolution().next().toString());
          moves.setText("Moves (" + counter + ") so far:" );
       }
       else
       {
          congratulations.setText("You solved the problem. Congratulations!");
       }
   
   });
  
   //Create hboxes
   HBox hbox = new HBox(8);
   HBox hbox2 = new HBox(8);
   
   //Create vboxes
   VBox vbcurrent = new VBox(8);
   VBox vbmoves = new VBox(8);
   VBox vbgoal = new VBox(8);
   VBox buttonBox = new VBox(8);
   VBox searchTypeBox = new VBox(8);
   VBox benchmarkBox = new VBox(8);
   VBox statisticsBox = new VBox(8);
   
   vbcurrent.getChildren().addAll(currentStateLabel,currentState);
   vbmoves.getChildren().addAll(moves, vbButton);
   vbgoal.getChildren().addAll(goalStateLabel,goalState);
   buttonBox.getChildren().addAll(nextButton,solveButton,resetButton);
   searchTypeBox.getChildren().addAll(searchLabel,searchType);
   benchmarkBox.getChildren().addAll(benchmarkLabel,benchmarkType);
   statisticsBox.getChildren().addAll(statisticsLabel,statisticsInfo);
   
   //place all the vboxes in the hbox
   hbox.getChildren().addAll(vbcurrent,vbmoves,vbgoal);
   hbox2.getChildren().addAll(buttonBox,searchTypeBox,benchmarkBox,statisticsBox);
   
   super.getChildren().addAll(welcomeMessage,introduction,hbox,illegalMove,congratulations,hbox2); //adds to GUI
   super.setAlignment(Pos.CENTER);
   super.setPadding(new Insets(15,15,15,15));
   hbox.setAlignment(Pos.CENTER);
   hbox2.setAlignment(Pos.BOTTOM_CENTER);
   }
    
    //private instance fields and helper methods 
    private Label introduction, welcomeMessage,congratulations;
    private Label currentState, currentStateLabel,goalState, goalStateLabel;
    private Label moves, illegalMove;
    private Button button,resetButton,nextButton,solveButton;
    private SolvingAssistant sa;
    private StateSpaceSolver bfs, dfs;
    private AStarSolver astar;
    private Solver solver;
    private int counter;
    private Benchmark b1,b2,b3,b4,b5,b6,b7,b8;
    private ObservableList<String>searchTypeList = FXCollections.observableArrayList();
}
