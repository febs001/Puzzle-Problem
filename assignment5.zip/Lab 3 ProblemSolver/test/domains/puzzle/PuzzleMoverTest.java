package domains.puzzle;

import framework.problem.Mover;
import framework.problem.State;
import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Your name here
 */
public class PuzzleMoverTest {
        
    /**
     * Declare private instance fields here. For example:
     */
    
    private final State start;
    private final Mover mover;
    private final String slide1, slide2, slide3, slide4,  // move names
	                 slide5, slide6, slide7, slide8;
    private final List<String> moveNames;
    private State next;
    
    
    public PuzzleMoverTest() {
         start = new PuzzleState(
                new int[][]{new int[]{2, 1, 3}, 
                            new int[]{8, 0, 4}, 
                            new int[]{7, 6, 5}}); //creates new constructor and creates array 
        
        mover = new PuzzleMover();
        moveNames = mover.getMoveNames();
        slide1 = moveNames.get(0);
        slide2 = moveNames.get(1);
        slide3 = moveNames.get(2);
        slide4 = moveNames.get(3);
        slide5 = moveNames.get(4);
        slide6 = moveNames.get(5);
        slide7 = moveNames.get(6);
        slide8 = moveNames.get(7);
    }
    
    /**
     * Test all moves in the methods below by replacing the calls to fail.
     */

    @Test
    public void testSlide1() {
        /**
         * For example, if mover, start, and slide1 have been
         * initialized, call:
         *
         *     mover.doMove(slide1, start)
         *
         * and test the result with assertions.
         */
       next = mover.doMove(slide1,start);
       assertTrue(next!=null);
       assertTrue(((PuzzleState)next).equals(new PuzzleState(
       new int[][]{new int[]{2, 0, 3}, 
                            new int[]{8, 1, 4}, 
                            new int[]{7, 6, 5}})));  
    }

    @Test
    public void testSlide2() {
        next = mover.doMove(slide2,start);
        assertTrue(next==null);
        //fail("The test case has not been implemented.");        
    }

    @Test
    public void testSlide3() {
        next = mover.doMove(slide3,start);
        assertTrue(next==null);
       //fail("The test case has not been implemented.");        
    }

    @Test
    public void testSlide4() {
       next = mover.doMove(slide4,start);
       assertTrue(next!=null);
       assertTrue(((PuzzleState)next).equals(new PuzzleState(
       new int[][]{new int[]{2, 1, 3}, 
                            new int[]{8, 4, 0}, 
                            new int[]{7, 6, 5}})));
        //fail("The test case has not been implemented.");        
    }

    @Test
    public void testSlide5() {
        next = mover.doMove(slide5,start);
        assertTrue(next==null);
        //fail("The test case has not been implemented.");        
    }

    @Test
    public void testSlide6() {
       next = mover.doMove(slide6,start);
       assertTrue(next!=null);
       assertTrue(((PuzzleState)next).equals(new PuzzleState(
       new int[][]{new int[]{2, 1, 3}, 
                            new int[]{8, 6, 4}, 
                            new int[]{7, 0, 5}})));
        //fail("The test case has not been implemented.");        
    }

    @Test
    public void testSlide7() {
        next = mover.doMove(slide7,start);
        assertTrue(next==null);
        //fail("The test case has not been implemented.");        
    }

    @Test
    public void testSlide8() {
       next = mover.doMove(slide8,start);
       assertTrue(next!=null);
       assertTrue(((PuzzleState)next).equals(new PuzzleState(
       new int[][]{new int[]{2, 1, 3}, 
                            new int[]{0, 8, 4}, 
                            new int[]{7, 6, 5}})));
        //fail("The test case has not been implemented.");        
    }
    
     /*private void doMoveIllegal(int [][] array, String m) {
        next = mover.doMove(m, new PuzzleState(array));
        assertTrue(next == null);
     }*/
     
     //private final String SLIDE1, SLIDE2, SLIDE3, SLIDE4, SLIDE5, SLIDE6, SLIDE7, SLIDE8;
}